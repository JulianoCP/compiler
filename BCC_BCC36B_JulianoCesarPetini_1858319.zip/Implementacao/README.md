# Como executar
Para rodar o programa é simples entre na pasta implementacao,
em seguida execute o comando

>python3 main.py
