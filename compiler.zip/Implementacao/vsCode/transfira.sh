#!/bin/bash
###---LINUX---###
#rm -r ~/.vscode/extensions/tpp/
cp -r tpp/ ~/.vscode/extensions/tpp/
cp -r tpptheme/ ~/.vscode/extensions/tpptheme/
###-----------------------------------------------###
