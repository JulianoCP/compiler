# Como executar
Para rodar o programa é simples entre na pasta implementação/parser, dentro do diretório
Utilize o comando

```python3 semantico.py arquivo .tpp'```

Lembrando que você precisa ter em sua máquina as bibliotecas AnyTree,Python Ply, Graphviz.
