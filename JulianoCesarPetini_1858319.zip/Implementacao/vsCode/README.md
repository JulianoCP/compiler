# ThemeTPP_VisualCode
Um tema da linguagem tpp para o visual code.

## Instalando

Para instalar basta dar permissão para o arquivo transfira.sh e depois execute ele

> chmod 777 transfira.sh
>
> ./transfira.sh

As pastas *tpp* e *tpptheme* serão instaladas no diretorio *~/.vscode/extensions/*

## Configuaração no Visual Code
Para utilizar o highlight em sua completude terá que selecionar o tema *tpptheme*, para fazer isso vá em:

> File->Preferences->Color Theme
>
> Ou CTRL+K+T

Irá abrir um campo de busca, digite TPP que irá aparecer o tema.


